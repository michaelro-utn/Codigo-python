# -*- coding: utf-8 -*-
"""
Created on Wed Dec 18 16:32:36 2019

@author: Michae
"""

import signals as sigs
from matplotlib import pyplot as plt
from matplotlib import style
from scipy import signal
import numpy as np


##Generar señal a convulcionar con su impulso
style.use('ggplot')
f, plt_arr =plt.subplots(2,sharex=True)
f.suptitle("Input signal and impulse response")
plt_arr[0].plot(sigs.airflow_100Hz)
plt_arr[1].plot(sigs.Impulse_response)
plt.show()

##Convolución de señal 
output_signal = signal.convolve(sigs.airflow_100Hz,sigs.Impulse_response, mode='same')

style.use('ggplot')

f,plt_arr = plt.subplots(3,sharex=True)
f.suptitle("Convolution")
plt_arr[0].plot(sigs.airflow_100Hz, color ='cyan')
plt_arr[0].set_title("Input Signal")
plt_arr[1].plot(sigs.Impulse_response, color ='blue')
plt_arr[1].set_title("Impulse Response")
plt_arr[2].plot(output_signal, color ='magenta')
plt_arr[2].set_title("Output Signal")

plt.show()

##Desconvolución señal
sig = np.array([0,0,0,0,1,1,1,1])
filter = np.array([1,1,0])

conv_result = signal.convolve(sig,filter)
deconv_result = signal.deconvolve(conv_result,filter)

print("Convolution result :")
print(conv_result)
print("Deconvolution result : ")
print(deconv_result)

##Correalación 
corr_output_signal = signal.correlate(sigs.airflow_100Hz, sigs.Impulse_response,mode ='same')
conv_output_signal = signal.convolve(sigs.airflow_100Hz, sigs.Impulse_response,mode ='same')

plt.plot(conv_output_signal)
plt.show()

