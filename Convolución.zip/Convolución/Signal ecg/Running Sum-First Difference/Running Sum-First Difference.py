# -*- coding: utf-8 -*-
"""
Created on Wed Dec 18 15:57:17 2019

@author: Michae
"""

from matplotlib import pyplot as plt
import signals as sigs
from matplotlib import style
from scipy import signal
import numpy as np

sig = np.array([0,0,0,0,1,1,1,1])
################RUNNING SUM ###########################
output_signal = np.cumsum(sigs.ecg_100Hz)

#style.use('ggplot')
style.use('dark_background')

f,plt_arr = plt.subplots(2,sharex=True)
f.suptitle("Running Sum")

plt_arr[0].plot(sigs.ecg_100Hz,color='yellow')
plt_arr[0].set_title("Input Signal")

plt_arr[1].plot(output_signal,color ='magenta')
plt_arr[1].set_title("Output Signal")

plt.show()


################FIRST DIFFERENCE#########################
output_signal = np.diff(sigs.ecg_100Hz)

style.use('dark_background')
#style.use('dark_background')

f,plt_arr = plt.subplots(2,sharex=True)
f.suptitle("First Difference")

plt_arr[0].plot(sigs.ecg_100Hz,color='red')
plt_arr[0].set_title("Input Signal")

plt_arr[1].plot(output_signal,color ='magenta')
plt_arr[1].set_title("Output Signal")

plt.show()